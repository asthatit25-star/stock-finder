# RuralCare (Blood and Medicine Availability Finder)

## Get the APK without installing anything
1. Create a free account on github.com and make a new repository.
2. Upload all files of this folder (keep the .github folder).
3. Open the repository, go to the Actions tab, and wait for "Build Android APK" to finish (about 5 minutes).
4. Open the finished run, download "ruralcare-apk", unzip it, and install app-debug.apk on your phone.

## Build on your own computer instead
Requires Node.js 20, Java 17 and Android Studio.
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android      (then Build > Build APK)

The app code is in www/index.html.
